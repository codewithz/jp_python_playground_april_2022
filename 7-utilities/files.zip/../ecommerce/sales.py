from ecommerce.customer import  contact

def calculate_tax():
    print("Tax Calculation")

def calculate_shipping():
    print("Shipping cost calculation")

def some_func():
    print("Inside Some FUnction")
    contact.get_customer_contact()
    print("Some Function ends here")